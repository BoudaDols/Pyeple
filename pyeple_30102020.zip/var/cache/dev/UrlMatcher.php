<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'default', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'register', '_controller' => 'App\\Controller\\RegistrationController::index'], null, null, null, false, false, null]],
        '/api/login_check' => [[['_route' => 'api_login_check'], null, null, null, false, false, null]],
        '/api/actualites/pub' => [[['_route' => 'pub_actualite', '_controller' => 'App\\Controller\\ActualiteController::pubActualiteAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/actualites/linked' => [[['_route' => 'linked_actualites', '_controller' => 'App\\Controller\\ActualiteController::linkedActualitesAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/actualites/others' => [[['_route' => 'others_actualites', '_controller' => 'App\\Controller\\ActualiteController::othersActualitesAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/actualites' => [
            [['_route' => 'get_actualites', '_controller' => 'App\\Controller\\ActualiteController::getActualitesAction', '_format' => null], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'post_actualite', '_controller' => 'App\\Controller\\ActualiteController::postActualiteAction', '_format' => null], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/actualite' => [[['_route' => 'patch_actualite', '_controller' => 'App\\Controller\\ActualiteController::patchActualiteAction', '_format' => null], null, ['PATCH' => 0], null, false, false, null]],
        '/api/hashtags/byname' => [[['_route' => 'byname_hashtag', '_controller' => 'App\\Controller\\HashtagController::bynameHashtagAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/hashtags/linked' => [[['_route' => 'linked_hashtag', '_controller' => 'App\\Controller\\HashtagController::linkedHashtagAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/hashtags/others' => [[['_route' => 'others_hashtag', '_controller' => 'App\\Controller\\HashtagController::othersHashtagAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/hashtags' => [
            [['_route' => 'get_hashtags', '_controller' => 'App\\Controller\\HashtagController::getHashtagsAction', '_format' => null], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'post_hashtag', '_controller' => 'App\\Controller\\HashtagController::postHashtagAction', '_format' => null], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/abonnements' => [[['_route' => 'post_abonnement', '_controller' => 'App\\Controller\\AbonementController::postAbonnementAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/abonnement' => [[['_route' => 'delete_abonnement', '_controller' => 'App\\Controller\\AbonementController::deleteAbonnementAction', '_format' => null], null, ['DELETE' => 0], null, false, false, null]],
        '/api/commentaires' => [[['_route' => 'post_commentaire', '_controller' => 'App\\Controller\\CommentaireController::postCommentaireAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/users/update' => [[['_route' => 'update_user', '_controller' => 'App\\Controller\\UserController::updateUserAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/users/names/test' => [[['_route' => 'test_user_name', '_controller' => 'App\\Controller\\UserController::testUserNameAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/users/numbers/change' => [[['_route' => 'change_user_number', '_controller' => 'App\\Controller\\UserController::changeUserNumberAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
        '/api/groupes' => [[['_route' => 'post_groupe', '_controller' => 'App\\Controller\\GroupeController::postGroupeAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/groupes/members' => [[['_route' => 'post_groupe_members', '_controller' => 'App\\Controller\\GroupeController::postGroupeMembersAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/groupe/member' => [[['_route' => 'delete_groupe_member', '_controller' => 'App\\Controller\\GroupeController::deleteGroupeMemberAction', '_format' => null], null, ['DELETE' => 0], null, false, false, null]],
        '/api/likes/actus' => [[['_route' => 'post_like_actu', '_controller' => 'App\\Controller\\LikeActuController::postLikeActuAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/like/actu' => [[['_route' => 'delete_like_actu', '_controller' => 'App\\Controller\\LikeActuController::deleteLikeActuAction', '_format' => null], null, ['DELETE' => 0], null, false, false, null]],
        '/api/likes/comments' => [[['_route' => 'post_like_comment', '_controller' => 'App\\Controller\\LikeCommentController::postLikeCommentAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/like/comment' => [[['_route' => 'delete_like_comment', '_controller' => 'App\\Controller\\LikeCommentController::deleteLikeCommentAction', '_format' => null], null, ['DELETE' => 0], null, false, false, null]],
        '/api/userhasgroupe' => [[['_route' => 'patch_userhasgroupe', '_controller' => 'App\\Controller\\UserhasgroupController::patchUserhasgroupeAction', '_format' => null], null, ['PATCH' => 0], null, false, false, null]],
        '/api/messages' => [[['_route' => 'post_message', '_controller' => 'App\\Controller\\MessageController::postMessageAction', '_format' => null], null, ['POST' => 0], null, false, false, null]],
        '/api/message/byreceiver' => [[['_route' => 'get_message_byreceiver', '_controller' => 'App\\Controller\\MessageController::getMessageByreceiverAction', '_format' => null], null, ['GET' => 0], null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/api/(?'
                    .'|actualites/([^/]++)(*:34)'
                    .'|hashtags/([^/]++)(*:58)'
                    .'|commentaires/([^/]++)(?'
                        .'|(*:89)'
                    .')'
                    .'|groupes/([^/]++)(*:113)'
                    .'|likecomments/([^/]++)(*:142)'
                    .'|messages/([^/]++)(?'
                        .'|(*:170)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        34 => [[['_route' => 'get_actualite', '_controller' => 'App\\Controller\\ActualiteController::getActualiteAction', '_format' => null], ['id'], ['GET' => 0], null, false, true, null]],
        58 => [[['_route' => 'get_hashtag', '_controller' => 'App\\Controller\\HashtagController::getHashtagAction', '_format' => null], ['id'], ['GET' => 0], null, false, true, null]],
        89 => [
            [['_route' => 'get_commentaire', '_controller' => 'App\\Controller\\CommentaireController::getCommentaireAction', '_format' => null], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'delete_commentaire', '_controller' => 'App\\Controller\\CommentaireController::deleteCommentaireAction', '_format' => null], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        113 => [[['_route' => 'patch_groupe', '_controller' => 'App\\Controller\\GroupeController::patchGroupeAction', '_format' => null], ['id'], ['PATCH' => 0], null, false, true, null]],
        142 => [[['_route' => 'get_likecomment', '_controller' => 'App\\Controller\\LikeCommentController::getLikecommentAction', '_format' => null], ['id'], ['GET' => 0], null, false, true, null]],
        170 => [
            [['_route' => 'get_message', '_controller' => 'App\\Controller\\MessageController::getMessageAction', '_format' => null], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'delete_message', '_controller' => 'App\\Controller\\MessageController::deleteMessageAction', '_format' => null], ['id'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'patch_message', '_controller' => 'App\\Controller\\MessageController::patchMessageAction', '_format' => null], ['id'], ['PATCH' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
